document.addEventListener("DOMContentLoaded", function() {
    // Any JavaScript needed for interactivity can be added here.
});
